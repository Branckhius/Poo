#include<iostream>
#include <vector>
using namespace std;
class Data {
public:
    Data() {
        zi = 0;
        luna = "";
        an = 0;
    }
    Data(const Data& other)
        :zi(other.zi), luna(other.luna), an(other.an)
    {
    }
    Data& operator=(const Data& other) {
        zi = other.zi;
        luna = other.luna;
        an = other.an;
        return *this;
    };
    ~Data() {
        
    }
    Data(const int alt_zi,const string alt_luna, const int alt_an)
    {
        this->zi = alt_zi;
        this->luna = alt_luna;
        this->an = alt_an;
    }
    friend istream& operator>>(istream& in, Data& d) {
        in >> d.zi >> d.luna >> d.an;
        return in;
    }
    friend ostream& operator<<(ostream& out, const Data& c) {
        out << c.zi << " " << c.luna << " " << c.an;
        return out;
    }
private:
    int zi;
    string luna;
    int an;
};


class Proprietar {
public:
    ~Proprietar() {
        
    }
    Proprietar() {
        data_nasterii = Data();
        nume = "";
    }
    Proprietar(const string alt_nume,Data alt_data_nasterii) {
        this->nume = alt_nume;
        this->data_nasterii = alt_data_nasterii;
    }
    Proprietar(const string alt_nume, const int alt_zi, const string alt_luna,const int alt_an)
        :nume(alt_nume), data_nasterii(alt_zi, alt_luna, alt_an) {
    }
    friend ostream& operator<<(ostream& out, const Proprietar& c) {
        out << c.nume;
        return out;
    }

private:
    string nume;
    Data data_nasterii;
};


class Casa {
public:
    ~Casa() {
        
    }
    Casa() {
        oras = "";
        nrProprietari = 0;
        Prop.clear();
    }
    Casa(string alt_oras) {
        this->oras = alt_oras;
        this->nrProprietari = 0;
        this->Prop.clear();

    }
    friend ostream& operator<<(ostream& out, const Casa& c) {
        out << c.oras << " " << c.nrProprietari;
        for (int i = 0; i < c.nrProprietari; i++) {
            out << c.Prop[i] << endl;
        }
        return out;
    }
    friend istream& operator>>(istream& in, Casa& c) {
        cout << "introduceti oras:";
            in >> c.oras;
        cout << " introduceti nrproprietar:";
        in>> c.nrProprietari;

        return in;
    }
    Casa& operator+=(const Proprietar& other)
    {
        Prop.push_back(other);
        nrProprietari++;
        return *this;
    };
private:
    string oras;
    int nrProprietari;
    vector<Proprietar> Prop;
};

int main() {
    Data d1(15,"Iulie",1975);
    Data d2(d1);
    Proprietar p1("Ionescu",d1);
    Proprietar p2("Popescu",2,"ianuarie",1980);
    Casa c1("Bucuresti");
    Casa c2;
    Casa c3;
    c1 += p1;
    c1 += p2;
    cout << c1;
    cin >> c2;
    c3 = c2;
    cout << c3;
}
